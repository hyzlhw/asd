package com.example.app_mvp.callback;


public interface IDataCallBack<T> {

    void onResponseData(T t);
    void onFalieData(String msg);
}

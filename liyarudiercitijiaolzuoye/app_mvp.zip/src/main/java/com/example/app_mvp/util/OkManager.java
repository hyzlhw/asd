package com.example.app_mvp.util;


import com.example.app_mvp.constant.ApiService;
import com.example.app_mvp.constant.Constants;
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;


/**
 * 封装网络请求框架
 */
public class OkManager {
    private static volatile OkManager okManager;
    private Retrofit rf;
    private OkManager(){
        initOk();
    }

    private void initOk() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(8, TimeUnit.SECONDS);
        builder.readTimeout(8,TimeUnit.SECONDS);
        builder.sslSocketFactory(HttpsTrustManager.createSSLSocketFactory());
        builder.hostnameVerifier(new HttpsTrustManager.TrustAllHostnameVerifier());
        rf=new Retrofit.Builder().client(builder
        .build()).baseUrl(Constants.BASE_URL).addCallAdapterFactory(RxJava2CallAdapterFactory.create()).build();
    }

    public static OkManager getInstance() {
        if (okManager==null){
            synchronized (OkManager.class){
                if (okManager==null){
                    synchronized (OkManager.class){
                        okManager=new OkManager();
                    }
                }
            }
        }
        return okManager;
    }
    public ApiService apiService(){
        if (rf!=null){
            return rf.create(ApiService.class);
        }
        return null;
    }
}

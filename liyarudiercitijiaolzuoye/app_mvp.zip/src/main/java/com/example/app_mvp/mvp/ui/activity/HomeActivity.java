package com.example.app_mvp.mvp.ui.activity;




import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.ViewPager;

import com.example.app_mvp.R;
import com.example.app_mvp.base.BaseActivity;
import com.example.app_mvp.mvp.ui.adapter.HomeVpAdapter;
import com.example.app_mvp.mvp.ui.fragment.HomeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;


public class HomeActivity extends BaseActivity {


    @BindView(R.id.home_viewpager)
    ViewPager homeViewpager;
    @BindView(R.id.home_navigation)
    BottomNavigationView homeNavigation;


    @Override
    protected int getLayout() {
        return R.layout.activity_main;
    }

    @Override
    protected void initListenner() {
        homeNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.item_home:
                        Log.e("TAG", "00000000");
                        switchTab(0);
                        break;
                    case R.id.item_navigation:
                        Log.e("TAG", "11111111");
                        switchTab(1);
                        break;
                    case R.id.item_tixi:
                        Log.e("TAG", "22222222");
                        switchTab(2);
                        break;
                    case R.id.item_gongzhonghao:
                        Log.e("TAG", "33333333");
                        switchTab(3);
                        break;
                }
                return true;
            }
        });
        homeViewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                //当ViewPager页面切换的时候让下面的tab标签跟着切换
                homeNavigation.getMenu().getItem(position).setChecked(true);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    protected void onViewCreated() {
        List<HomeFragment> fragments=getHomeFragments();
        HomeVpAdapter homeVpAdapter = new HomeVpAdapter(getSupportFragmentManager(), fragments);
        homeViewpager.setAdapter(homeVpAdapter);
    }


    private void switchTab(int i) {
        homeViewpager.setCurrentItem(i);
    }


    public List<HomeFragment> getHomeFragments() {
        List<HomeFragment> fragments=new ArrayList<HomeFragment>();
        for (int i = 0; i < 4; i++) {
            HomeFragment homeFragment = new HomeFragment(i);
            fragments.add(homeFragment);
        }
        return fragments;
    }
}

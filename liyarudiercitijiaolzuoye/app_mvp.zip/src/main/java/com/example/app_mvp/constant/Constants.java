package com.example.app_mvp.constant;

public class Constants {
    public static  String BASE_URL="https://wanandroid.com/";
    //公众号列表
    public static String CHAPTERS_LIST=BASE_URL+"wxarticle/chapters/json";

}

package com.example.app_mvp.mvp.ui.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.app_mvp.mvp.ui.fragment.HomeFragment;

import java.util.List;

public class HomeVpAdapter extends FragmentPagerAdapter {
    private List<HomeFragment> homeFragments;

    public HomeVpAdapter(@NonNull FragmentManager fm, List<HomeFragment> fragments) {
        super(fm);
        this.homeFragments = fragments;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return homeFragments.get(position);
    }

    @Override
    public int getCount() {
        return homeFragments.size();
    }
}

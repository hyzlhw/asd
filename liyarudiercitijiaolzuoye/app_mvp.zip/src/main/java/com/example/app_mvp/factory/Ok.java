package com.example.app_mvp.factory;

import android.util.Log;

import com.example.app_mvp.constant.ApiService;
import com.example.app_mvp.constant.Constants;
import com.example.app_mvp.mvp.model.entity.ChaptersListInfo;
import com.example.app_mvp.util.OkManager;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Ok implements Shape {
    @Override
    public void getNetwork() {
        ApiService apiService = OkManager.getInstance().apiService();
        apiService.getData(Constants.CHAPTERS_LIST).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    String string = response.body().string();
                    Gson gson = new Gson();
                    ChaptersListInfo chaptersListInfo = gson.fromJson(string, ChaptersListInfo.class);
                    List<ChaptersListInfo.DataBean> data = chaptersListInfo.getData();
                    Log.e("TAG","-----------------------"+data.get(0).getName());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.e("TAG","-----------------------------失败----------------------------------");
            }
        });
    }
}

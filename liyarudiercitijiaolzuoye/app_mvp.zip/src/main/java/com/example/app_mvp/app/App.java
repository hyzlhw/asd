package com.example.app_mvp.app;

import android.app.Activity;
import android.app.Application;

import java.util.HashSet;
import java.util.Set;

public class App extends Application {
    private static App mInstance;
    private Set<Activity> mActivites;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance=this;
        initInject();
    }

    private void initInject() {


    }
    public static synchronized App getInstance(){
        return mInstance;
    }
    public void addActivity(Activity activity){
        if (mActivites==null){
            mActivites=new HashSet<Activity>();
            mActivites.add(activity);
        }
    }
    public void removeActivity(){
        if (mActivites!=null){
            for (Activity activity:mActivites) {
                activity.finish();
            }
        }
        System.exit(0);
    }
}

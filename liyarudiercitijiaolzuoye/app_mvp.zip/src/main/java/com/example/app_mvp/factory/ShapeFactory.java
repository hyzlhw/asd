package com.example.app_mvp.factory;

public class ShapeFactory {
    //使用 getShape 方法获取形状类型的对象
    public Shape getShape(String shapetype){
        if (shapetype==null){
            return null;
        }
        if (shapetype.equalsIgnoreCase("Ok")){
           return new Ok();
        }else if (shapetype.equalsIgnoreCase("Re")){
            return new Re();
        }
        return null;
    }
}

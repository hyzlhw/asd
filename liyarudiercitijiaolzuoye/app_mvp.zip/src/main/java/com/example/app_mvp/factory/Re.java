package com.example.app_mvp.factory;

import android.util.Log;

import com.example.app_mvp.callback.IDataCallBack;
import com.example.app_mvp.constant.Constants;
import com.example.app_mvp.mvp.model.entity.ChaptersListInfo;
import com.example.app_mvp.util.RxImplutil;


public class Re  implements Shape {

    private RxImplutil rx;

    @Override
    public void getNetwork()  {
        rx = new RxImplutil();
        rx.getChaotersList(Constants.CHAPTERS_LIST, new IDataCallBack() {
            @Override
            public void onResponseData(Object o) {
                if (o instanceof ChaptersListInfo){
                    ChaptersListInfo chaptersListInfo=(ChaptersListInfo) o;
                    String name = chaptersListInfo.getData().get(0).getName();
                    Log.e("TAG","-----------------sssssssssssssssss-----"+name);
                }
            }

            @Override
            public void onFalieData(String msg) {
                    Log.e("TAG","----ssssssssssssssssssssss"+msg);
            }
        });
    }


}

package com.example.app_mvp.mvp.presenter;

import android.util.Log;

import com.example.app_mvp.base.BasePresenter;


public class HomePresenter extends BasePresenter {
    //向M层请求数据

    @Override
    public void start(Object o) {
        super.start(o);
        if (o instanceof  Integer){
            Integer type=(Integer)o;
            switch (type){
                case 0:
                    Log.e("TAG", "第一个Fragment开始加载数据了....");
                    break;
                case 1:
                    Log.e("TAG", "第二个Fragment开始加载数据了....");
                    break;
                case 2:
                    Log.e("TAG", "第三个Fragment开始加载数据了....");
                    break;
                case 3:
                    Log.e("TAG", "第四个Fragment开始加载数据了....");
                    break;
            }
        }
    }
}

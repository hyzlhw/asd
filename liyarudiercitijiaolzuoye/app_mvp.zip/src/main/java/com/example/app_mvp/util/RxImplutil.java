package com.example.app_mvp.util;


import com.example.app_mvp.callback.IDataCallBack;
import com.example.app_mvp.mvp.model.entity.ChaptersListInfo;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Model层  请求数据
 */
public class RxImplutil {
    private OkManager okManager;
    public RxImplutil(){
        okManager=OkManager.getInstance();
    }
    //model层请求完成数据之后 通过接口回调的方式交给传递的P层
    //请求数据需要用接口回调然后将数据交给P层 所以不需要任何类型的返回值
    public void getChaotersList(String url, final IDataCallBack callBack){
        Call<ResponseBody> call = okManager.apiService().getData(url);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    String json = response.body().string();
                    ChaptersListInfo chaptersListInfo = GsonUtil.jsonStrToBean(json, ChaptersListInfo.class);
                    //接口回调
                    callBack.onResponseData(chaptersListInfo);
                } catch (IOException e) {
                    e.printStackTrace();
                    callBack.onFalieData(e.getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                callBack.onFalieData(t.getMessage());
            }
        });
    }
}

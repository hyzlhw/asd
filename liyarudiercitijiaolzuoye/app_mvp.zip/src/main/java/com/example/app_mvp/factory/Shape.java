package com.example.app_mvp.factory;

public interface Shape {
    void getNetwork();
}
